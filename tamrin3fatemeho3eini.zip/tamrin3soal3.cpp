
#include"iostream"

using namespace std;

int main()
{
	int ary[80], n, flag = 1;
	cout << "Enter number: ";
	cin >> n;

	cout << "Enter " << n << " number: ";
	for (int i = 0; i < n; i++)
		cin >> ary[i];

	for (int i = 0; i < n - 1; i++) {
		if (ary[i] > ary[i + 1])
			flag = 0;
	}
	if (flag == 1) {
		cout << "array is arranged." << endl;
	}
	else {
		cout << "array is not tidy." << endl;
	}
	return 0;
}


