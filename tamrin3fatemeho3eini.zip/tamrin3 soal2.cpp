
#include"iostream"
#include"time.h"

using namespace std;

int main()
{
	int ary[80], n, t, flag;
	cout << "Enter number: ";
	cin >> n;
	srand(time(0));
	for (int i = 0; i < n; i++) {
		flag = 1;
		t = rand() % n;
		for (int k = 0; k < i; k++)
		{
			if (t == ary[k]) {
				flag = 0;
				break;
			}
		}
		if (flag)
			ary[i] = t;
		else
			i--;
	}
	cout << "numbers: ";
	for (int i = 0; i < n; i++)
		cout << ary[i] << "   ";
	return 0;
}


